package com.github.badaccuracy.id.dutisa;

public class DuTiSaLauncher {

    public static void main(String[] args) {
        DuTiSa.main(args);
    }

}
